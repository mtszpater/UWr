class Vehicle {

    constructor(curPos,fueCons,tanStat){

        if (new.target === Vehicle) {
            throw new TypeError("Cannot construct Abstract instances directly");
        }

        if( fueCons < 0 ){
            throw new TypeError('value of fuelConsumption needs to be bigger than 0');
        }

        if( tanStat < 0 ){
            throw new TypeError('value of tankStatus needs to be bigger than 0');
        }

        this.currentPosition = curPos;
        this.fuelConsumption = fueCons;
        this.tankStatus = tanStat;
    }

    get _currentPosition(){
        return this.currentPosition;
    }

    set _currentPosition(value){
        if (value < 0) {
            console.log("We do not support undead animals");
        }
        this.currentPosition = value;
    }

    get _fuelConsumption(){
        return this.fuelConsumption;
    }

    set _fuelConsumption(value){
        this.fuelConsumption = value;
    }

    get _tankStatus(){
        return this.tankStatus;
    }

    set _tankStatus(value){
        this.tankStatus = value;
    }

    loadFuel(fuel){
        if( fuel < 0 ){
            alert("More than 0!");
        }

        this.tankStatus += fuel;
    }


    move(x,y){

        var count = x + y;

        if( count*this.fuelConsumption > this.tankStatus )
        {
            alert("Need fuel to move!");
        }
        else
        {
            this.currentPosition += count;
            this.tankStatus -= count*this.fuelConsumption;
        }

    }

}

class Car extends Vehicle{

    constructor(curPos,fueCons,tanStat) {
        super(curPos, fueCons, tanStat)
    }

    description(){
        return "<img id='car' src='car.png'> This is CAR - Tank status : " + this.tankStatus + " Fuel consumption : " + this.fuelConsumption + " Current position : "  + this.currentPosition;
    }

}

class Truck extends Vehicle{

    constructor(curPos,fueCons,tanStat) {
        super(curPos, fueCons, tanStat)
    }

    description(){
        return "<img id='truck' src='truck.png'> This is TRUCK - Tank status : " + this.tankStatus + " Fuel consumption : " + this.fuelConsumption + " Current position : "  + this.currentPosition;
    }

}


var truck;
var car;

function createVehicle() {

    var veh = new Vehicle(0, 15, 150);
    
}

function createCar() {

    car = new Car(0, 15, 150);

    document.getElementById("statusBarForCar").innerHTML = car.description();
    document.getElementById("menuCar").style.display = "block";

}

function createTruck() {

    truck = new Truck(0, 15, 150);

    document.getElementById("statusBarForTruck").innerHTML = truck.description();
    document.getElementById("menuTruck").style.display = "block";
}


function loadFuelCar() {

    car.loadFuel(1);

    document.getElementById("statusBarForCar").innerHTML = car.description();

}

function loadFuelTruck() {

    truck.loadFuel(1);

    document.getElementById("statusBarForTruck").innerHTML = truck.description();

}


function moveCar() {

    car.move(1,0);

    document.getElementById("statusBarForCar").innerHTML = car.description();

}

function moveTruck() {

    truck.move(1,0);

    document.getElementById("statusBarForTruck").innerHTML = truck.description();

}